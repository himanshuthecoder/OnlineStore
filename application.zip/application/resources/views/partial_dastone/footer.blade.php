<?php
$baseurl=url('/');
?>
        <!-- jQuery  -->
        <script src="{{$baseurl}}/dastone/js/bootstrap.bundle.min.js"></script>
        <script src="{{$baseurl}}/dastone/js/metismenu.min.js"></script>
        <script src="{{$baseurl}}/dastone/js/waves.js"></script>
        <script src="{{$baseurl}}/dastone/js/feather.min.js"></script>
        <script src="{{$baseurl}}/dastone/js/simplebar.min.js"></script>
        <script src="{{$baseurl}}/dastone/js/moment.js"></script>
        <script src="{{$baseurl}}/dastone/plugins/apex-charts/apexcharts.min.js"></script>
        <script src="{{$baseurl}}/dastone/plugins/sweet-alert2/sweetalert2.min.js" > </script>
        <script src="{{$baseurl}}/dastone/plugins/daterangepicker/daterangepicker.js"></script>
        <script src="{{$baseurl}}/dastone/plugins/lightpick/lightpick.js" > </script>
        <script src="{{$baseurl}}/dastone/plugins/leaflet/leaflet.js"></script>
        <script src="{{$baseurl}}/dastone/plugins/lightpick/lightpick.js"></script>
        <script src="{{$baseurl}}/dastone/pages/jquery.form-upload.init.js"></script>
        <script src="{{$baseurl}}/dastone/plugins/dropify/js/dropify.min.js"></script>
        <script src="{{$baseurl}}/dastone/plugins/dragula/dragula.min.js"></script>
        <script src="{{$baseurl}}/dastone/plugins/select2/select2.min.js" > </script>
        <script src="{{$baseurl}}/dastone/plugins/repeater/jquery.repeater.min.js"></script>
        <!-- App js -->
        <script src="{{$baseurl}}/dastone/js/app.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/jquery-ui-sortable@1.0.0/jquery-ui.min.js"></script>
    <script src="{{$baseurl}}/dastone/plugins/datatables/jquery.dataTables.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/datatables/dataTables.bootstrap4.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/datatables/dataTables.responsive.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/datatables/dataTables.buttons.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/datatables/buttons.bootstrap4.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/datatables/jszip.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/datatables/pdfmake.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/datatables/vfs_fonts.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/datatables/buttons.html5.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/datatables/buttons.print.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/datatables/buttons.colVis.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/datatables/dataTables.responsive.min.js"></script>
    <script src="{{$baseurl}}/dastone/plugins/datatables/responsive.bootstrap4.min.js" > </script>
    <script src="{{$baseurl}}/dastone/pages/jquery.datatable.init.js"></script>
    <script src="{{$baseurl}}/dastone/plugins/summernote/summernote-bs4.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/tiny-editable/mindmup-editabletable.js"></script>
    <script src="{{$baseurl}}/dastone/plugins/tiny-editable/numeric-input-example.js"></script>
    <script src="{{$baseurl}}/dastone/plugins/bootable/bootstable.js"></script>
    <script src="{{$baseurl}}/dastone/pages/jquery.tabledit.init.js"></script>
    <script src="{{$baseurl}}/dastone/plugins/ion-rangeslider/ion.rangeSlider.min.js"></script>
    <script src="{{$baseurl}}/dastone/pages/jquery.rangeslider.init.js"></script>
  <!-- Will Add According to needs-->
<!--
        <script src="{{$baseurl}}/dastone/plugins/daterangepicker/daterangepicker.js"></script>
        <script src="{{$baseurl}}/dastone/plugins/apex-charts/apexcharts.min.js"></script>
        <script src="{{$baseurl}}/dastone/pages/jquery.analytics_dashboard.init.js"></script>
        <script src="{{$baseurl}}/dastone/pages/jquery.profile.init.js"></script>
        <script src="{{$baseurl}}/dastone/pages/jquery.analytics_dashboard.init.js"></script>
    <script src="{{$baseurl}}/dastone/plugins/apex-charts/apexcharts.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/apex-charts/irregular-data-series.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/apex-charts/ohlc.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/bootable/bootstable.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/bootstrap-maxlength/bootstrap-maxlength.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/bootstrap-session-timeout/bootstrap-session-timeout.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/bootstrap-touchspin/js/jquery.bootstrap-touchspin.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/chartjs/chart.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/clipboard/clipboard.min.js" > </script>

    <script src="{{$baseurl}}/dastone/plugins/daterangepicker/daterangepicker.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/dragula/dragula.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/dropify/js/dropify.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/flot-chart/jquery.canvaswrapper.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/flot-chart/jquery.colorhelpers.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/flot-chart/jquery.flot.axislabels.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/flot-chart/jquery.flot.browser.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/flot-chart/jquery.flot.drawSeries.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/flot-chart/jquery.flot.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/flot-chart/jquery.flot.legend.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/flot-chart/jquery.flot.pie.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/flot-chart/jquery.flot.saturated.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/flot-chart/jquery.flot.stack.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/flot-chart/jquery.flot.tooltip.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/flot-chart/jquery.flot.uiConstants.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/gmaps/gmaps.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/idle-timer/idle-timer.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/ion-rangeslider/ion.rangeSlider.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/jquery-steps/jquery.steps.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/jvectormap/gdp-data.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/jvectormap/jquery-jvectormap-2.0.2.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/jvectormap/jquery-jvectormap-ca-lcc.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/jvectormap/jquery-jvectormap-uk-mill-en.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/jvectormap/jquery-jvectormap-us-aea-en.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/jvectormap/jquery-jvectormap-us-il-chicago-mill-en.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/jvectormap/jquery-jvectormap-world-mill-en.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/leaflet/leaflet.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/lightbox/jquery.magnific-popup.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/lightpick/lightpick.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/morris/morris.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/nestable/jquery.nestable.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/parsleyjs/parsley.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/raphael/raphael.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/rating/jquery.barrating.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/repeater/jquery.repeater.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/RWD-Table-Patterns/dist/js/rwd-table.min.js" > </script>


    <script src="{{$baseurl}}/dastone/plugins/sweet-alert2/sweetalert2.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/timepicker/bootstrap-material-datetimepicker.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/tiny-editable/mindmup-editabletable.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/tiny-editable/numeric-input-example.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/tinymce/tinymce.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/tippy/tippy.all.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/treeview/jstree.min.js" > </script>
    <script src="{{$baseurl}}/dastone/plugins/x-editable/js/bootstrap-editable.min.js" > </script>
 -->

        <script>
        menuaction('dashboard');

        </script>

    </body>

</html>
